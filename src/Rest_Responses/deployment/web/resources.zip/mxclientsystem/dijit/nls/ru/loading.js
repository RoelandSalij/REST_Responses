//>>built
define("dijit/nls/ru/loading",({loadingState:"Загрузка...",errorState:"Извините, возникла ошибка"}));
