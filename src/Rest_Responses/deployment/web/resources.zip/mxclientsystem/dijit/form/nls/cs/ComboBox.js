//>>built
define("dijit/form/nls/cs/ComboBox",({previousMessage:"Předchozí volby",nextMessage:"Další volby"}));
